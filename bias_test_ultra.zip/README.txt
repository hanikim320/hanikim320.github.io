# 링크 배포 가이드 (CDN 없이 동작 · 예쁜 UI 버전)

- 파일: `index.html` 1개 (스타일/스크립트 모두 내장)
- 배포(추천): GitHub Pages
  1) 새 저장소 → `index.html` 업로드
  2) Settings → Pages → Branch: `main`, Folder: `/root` → Save
  3) 배포 주소: `https://<본인아이디>.github.io/<저장소명>`
- Netlify/Vercel/학교 NAS에도 그대로 사용 가능
- QR 코드는 배포 URL로 만들면 됩니다.
